<?php
define('APP_NAME', 'SIMUDA');