<?php
function base_url($path = '') { return 'http://localhost/' . $path; }